import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, "data");
const SESSIONS_FILE = path.join(DATA_DIR, "sessions.json");
const USERS_FILE = path.join(DATA_DIR, "users.json");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR);
}

// Helper to load data
function loadData(filePath: string, defaultValue: any) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, "utf-8"));
    }
  } catch (e) {
    console.error(`Error loading ${filePath}:`, e);
  }
  return defaultValue;
}

// Helper to save data
function saveData(filePath: string, data: any) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error(`Error saving ${filePath}:`, e);
  }
}

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // Load data from files
  let sessions: any[] = loadData(SESSIONS_FILE, []);
  let users: any[] = loadData(USERS_FILE, []);

  app.use(express.json());

  // API Routes
  app.get("/api/sessions", (req, res) => {
    res.json(sessions);
  });

  app.get("/api/users", (req, res) => {
    res.json(users);
  });

  // Socket.io logic
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    // Send initial data
    socket.emit("init", { sessions, users });

    socket.on("session:create", (session) => {
      sessions = [session, ...sessions];
      saveData(SESSIONS_FILE, sessions);
      io.emit("session:created", session);
    });

    socket.on("session:update", (updatedSession) => {
      sessions = sessions.map(s => s.id === updatedSession.id ? updatedSession : s);
      saveData(SESSIONS_FILE, sessions);
      io.emit("session:updated", updatedSession);
    });

    socket.on("session:delete", (sessionId) => {
      sessions = sessions.filter(s => s.id !== sessionId);
      saveData(SESSIONS_FILE, sessions);
      io.emit("session:deleted", sessionId);
    });

    socket.on("user:update", (user) => {
      const index = users.findIndex(u => u.id === user.id);
      if (index !== -1) {
        users[index] = user;
      } else {
        users.push(user);
      }
      saveData(USERS_FILE, users);
      io.emit("user:updated", user);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
